// Kyle Phillips


#ifndef WIND_H
#define WIND_H

#include <iostream>
#include <string>
#include <sstream>

using namespace std;

struct wind {
	
int speed;	
string direction;

public:
	void getWind();
	void printWind();

};

#endif
