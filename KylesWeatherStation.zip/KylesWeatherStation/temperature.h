// Kyle Phillips


#pragma once
#ifndef TEMPERATURE_H
#define TEMPERATURE_H

class temperature {
	int temp;

public:
	void getTemperature();

	void printTemperature();

};
#endif
